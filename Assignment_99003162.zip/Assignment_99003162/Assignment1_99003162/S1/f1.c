#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>


int main()
{
	int filedescriptor,numberbytes;
	int filedescriptor1,number1bytes;
	filedescriptor=open("srcfile.txt",O_RDONLY);
	if(filedescriptor<0)
	{
		perror("open");
		exit(1);
	}
	int maximumlength=128;
	char buffer[maximumlength];
	numberbytes=read(filedescriptor,buffer,maximumlength);
	if(numberbytes<0)
	{
		perror("read");
		exit(1);
	}
	buffer[numberbytes]='\0';

	filedescriptor1=open("destfile.txt",O_WRONLY|O_CREAT|O_TRUNC,0666);
	
	if(filedescriptor1<0)
	{
		perror("open");
		exit(2);
	}
	
	number1bytes=write(filedescriptor1,buffer,numberbytes);
	printf("The copy of the file is succesfull\n");

	close(filedescriptor1);
	close(filedescriptor);
	return 0;
}

#include "fact.h"

int factfun(int n)
{
  /* function return -1 for negative numbers */
  if(n < 0)
    return -1;

  /* function return 1 for 0 */
  if(n == 0)
    return 1;

  /* this recursively calculate factorial of the number */
  return n * factfun(n-1);
}

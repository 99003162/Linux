#ifndef __CIRCULARSEMAPHORE_H
#define __CIRCULARSEMAPHORE_H

#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>

#endif
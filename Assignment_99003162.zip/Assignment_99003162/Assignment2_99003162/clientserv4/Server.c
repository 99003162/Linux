#include "ServerClient.h"

int main()
{
	int ret_rn,numbytes;
	struct mq_attr attribt;
	attribt.mq_msgsize=256;
	attribt.mq_maxmsg=10;
	mqd_t mqueid;
	/* Open a Message Queue in Server Process */
	mqueid=mq_open("/mque",O_CREAT | O_RDWR,0666,&attribt);
	if(mqueid<0)
	{
		perror("mq_open");
		exit(1);
	}

	char buff[8192];
	int maxlen=256,prio;
	/* Receive a message from Queue */
	printf("Waiting for Client Message .......\n");
	numbytes=mq_receive(mqueid,buff,maxlen,&prio);
	if(numbytes<0)
	{
		perror("mq_recv");
		exit(2);
	}
	buff[numbytes]='\0';
	printf("CLIENT MESSAGE: %s\n",buff);

	/* Toogle the message received */
	for (int i=0; buff[i]!='\0'; i++)
    {
        if (buff[i]>='A' && buff[i]<='Z')
            buff[i] = buff[i] + 'a' - 'A';
        else if (buff[i]>='a' && buff[i]<='z')
            buff[i] = buff[i] + 'A' - 'a';
    }

	/* Send back the processed message to Client through Queue */
	ret_rn = mq_send(mqueid,buff,100,100);
	if(ret_rn < 0)
	{
		perror("mq_send");
		exit(2);
	}
	/* Close the Queue */
	mq_close(mqueid);
	return 0;
}


#include "ServerClient.h"

int main()
{
	int ret_rn, numbytes;
	mqd_t mqueid;
	struct mq_attr attribt;
	attribt.mq_msgsize=256;
	attribt.mq_maxmsg=10;
	/* Open a Message Queue in Client Process */
	mqueid=mq_open("/mque",O_CREAT | O_RDWR,0666,&attribt);
	if(mqueid<0)
	{
		perror("mq_open");
		exit(1);
	}

	char str[20] = "HI HOW ARE YOU";
	/* Send a message to Queue */
	ret_rn=mq_send(mqueid,str,20,5);
	if(ret_rn<0)
	{
		perror("mq_send");
		exit(2);
	}

	char buff[8192];
	int maxlen=256,prio;
	/* Receive the message from Server through Queue */
	numbytes=mq_receive(mqueid,buff,maxlen,&prio);
	if(numbytes<0)
	{
		perror("mq_recv");
		exit(2);
	}
	buff[numbytes]='\0';
	printf("SERVER MESSAGE : %s\n",buff);
	/* Close the Queue */
	mq_close(mqueid);

	return 0;
}


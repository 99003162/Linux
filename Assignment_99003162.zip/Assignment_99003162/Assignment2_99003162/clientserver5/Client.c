#include "ServerClient.h"

int main()
{
	int ret_1,numberbytes1;
	struct mq_attr attribute;
	attribute.mq_msgsize=256;
	attribute.mq_maxmsg=10;
	mqd_t mqid3;
	/* Open a Message Queue in Client Process */
	mqid3=mq_open("/mque1",O_RDONLY|O_CREAT,0666,&attribute);
	if(mqid3<0)
	{
		perror("mq_open");
		exit(1);
	}
	char buffer[8192];
	int maxlen=256,prio;
	numberbytes1=mq_receive(mqid3,buffer,maxlen,&prio);
	if(numberbytes1<0)
	{
		perror("mq_recv");
		exit(2);
	}
	buffer[numberbytes1]='\0';
	int k;
    printf("%s",buffer);
	
	k=execlp("/bin/gcc","gcc",buffer,0);
    if(k<0)
		{
			perror("execlp");
			exit(1);
		}
		exit(5);
		
	printf("receive message:%s,nbytes=%d,prio=%d\n",buffer,numberbytes1,prio);
	mq_close(mqid3);
	return 0;
}


#include "StackSemaphores.h"

#define Maximumelems 5 
/* BufferSize set to 5 */
#define BufferSize 5

sem_t clear;
sem_t full;
int inp= 0;
int oup= 0;
int elem = 0;
int buff[BufferSize];

void *producer(void *producer_num) {
  if (inp== BufferSize - 1) {
    printf("Producer Stack is full \n");
  } 
  else {
    for (int i = 0; i < Maximumelems; i++) {
      elem = rand();
      sem_wait(&clear);
      /* put value elem into the buff */
      buff[inp] = elem;
      printf("Producer %d: Insert elem %d at %d\n", *((int *)producer_num), buff[inp],
             inp);
      inp= (inp+ 1) % BufferSize;
      sem_post(&full);
    }
  }
}

void *consumer(void *consumer_num) {
  if (oup== BufferSize - 1) {
    printf("Consumer Stack is full\n");
  } 
  else {
    int elem = 0;
    for (int i = 0; i < Maximumelems; i++) {
      sem_wait(&full);
      /* take one unit of data from the buff */
      elem = buff[oup];
      printf("Consumer %d: Remove elem %d from %d\n", *((int *)consumer_num), elem, oup);
      oup= (oup+ 1) % BufferSize;
      sem_post(&clear);
    }
  }
}

void main() {
  pthread_t pro[5], con[5];
  sem_init(&clear, 0, BufferSize);
  sem_init(&full, 0, 0);

  int a[5] = {1, 2, 3, 4, 5}; 

  for (int i = 0; i < 5; i++) {
    pthread_create(&pro[i], NULL, (void *)producer, (void *)&a[i]);
  }
  for (int i = 0; i < 5; i++) {
    pthread_create(&con[i], NULL, (void *)consumer, (void *)&a[i]);
  }

  for (int i = 0; i < 5; i++) {
    pthread_join(pro[i], NULL);
  }
  for (int i = 0; i < 5; i++) {
    pthread_join(con[i], NULL);
  }

  sem_destroy(&clear);
  sem_destroy(&full);
}

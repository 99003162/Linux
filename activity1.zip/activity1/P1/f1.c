#include <string.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include <sys/wait.h>

int main()
{
	int ret_tr,returni_tr;
	
	printf("Enter the command: \n");
	char str[100];
	scanf(" %[^\n]s\n",str);
	ret_tr=fork();
	if(ret_tr<0)
	{
		perror("fork");
		exit(1);
	}
	if(ret_tr==0)
	{ 
	    	execl("/bin/sh","sh","-c",str,NULL) ; 
	}
	else	
	{
		waitpid(ret_tr, &returni_tr, 0); 
	}
	exit(0);
}

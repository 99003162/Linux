#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
	int filedescriptor,numberbytes;
	int wd=0,ln1=0,tr;	
	int inwd=0;
	filedescriptor=open("srcfile.txt",O_RDONLY);
	if(filedescriptor<0)
	{
		perror("open");
		exit(1);
	}
	int maximumlength=128;
	char buffer[maximumlength];
	numberbytes=read(filedescriptor,buffer,maximumlength);
	if(numberbytes<0)
	{
		perror("read");
		exit(2);
	}
	else
	{
	tr=0;
	while(tr!=numberbytes)
	{ 
	 if(buffer[tr]==' '|| buffer[tr]=='\t' ||buffer[tr]=='\n' ||buffer[tr]=='\0')
	 {

	 if(inwd)
	 {
	 inwd=0;
	 wd++;
	 }
	 
	 if(buffer[tr]=='\n'||buffer[tr]=='\0')
	 ln1++;
	 }
	 else
	 {
	 inwd=1;
	 }
	 tr++;
	}
	}
	printf("\nwd :%d ln1 :%d char:%d\n",wd,ln1,numberbytes);
	close(filedescriptor);
	return 0;	
}

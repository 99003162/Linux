#include <stdio.h>
int main()
{
	int a=5,b=10,c;
	c=a*b;
	printf("\n%d",c);
	return 0;
}

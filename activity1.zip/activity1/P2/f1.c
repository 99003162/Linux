#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
    int ret_tr;
    printf("Parent PID %d\n",getpid());
    ret_tr = fork();

    switch(ret_tr)
    {
        case 0 :printf("child--welcome,pid=%d,ppid=%d\n",
			    getpid(),getppid());
                execl("/usr/bin/gcc","gcc","mul.c","-o","st",NULL);
                execl("./st","st",NULL);  
                break;
        case -1: perror("fork");
		         exit(1);
        default:printf("parent--hello,pid=%d,ppid=%d\n",
			    getpid(),getppid());
                break;                 
    }
    return 0;
}

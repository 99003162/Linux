#include "fact.h"
#include <stdio.h>

int main(void)
{
	int n=4;
	printf("Factorial is %d\n", factfun(n));
	return 0;
}

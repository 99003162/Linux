/**
* @file fact.h
*
*/
#ifndef __FACT_H__
#define __FACT_H__

/**
* Calculates the factorial of integer number
* @param[in] number for which factorial has to be found
* @return Factorial of the number
* @note Returns -1 for negative values
*/
int factfun(int number);

#endif /* #ifndef __FACT_H__ */

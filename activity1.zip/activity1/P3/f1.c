#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>

int main()
{
    int v1,v2,v3;
    int ret_t;
    v1 = fork();

    if(v1==0)
    {
        execl("/usr/bin/gcc","gcc","-c","-Iinc","src/fact.c","main.c",NULL);
    }
    else if(v1<0)
    {
        perror("Error in child1");
        exit(0);
    }
    else
    {
        printf("Inside the child1\n");
        waitpid(v1,&ret_t,0);
        v2 = fork();
    }
    if(v2==0)
    {
        execl("/usr/bin/gcc","gcc","-Iinc","fact.o","main.o","-o","all.out",NULL);
    }
    else if(v2<0)
    {
        perror("Error in child2");
        exit(1);
    }    
    else
    {
        printf("Inside the child2\n");
        waitpid(v2,&ret_t,0);
        v3 = fork();
    }
    if(v3==0)
    {
        execl("all.out","all.out",NULL);
    }
    else if(v3<0)
    {
        perror("Error child3");
        exit(3);
    }    
    else
    {
        waitpid(v3,&ret_t,0);
    }
    
    return 0;
}
